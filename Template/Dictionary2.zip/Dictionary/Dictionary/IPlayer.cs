namespace Dictionary;

public interface IPlayer
{
    string UserName {get;set;}
}
