namespace GameCheckker.Class;

public enum PieceType
{
    Empty,
    White,
    Black
}
