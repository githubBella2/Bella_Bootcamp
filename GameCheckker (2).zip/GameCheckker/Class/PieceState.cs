namespace GameCheckker.Class;

public enum PieceState
{
    Normal,
    King
}
